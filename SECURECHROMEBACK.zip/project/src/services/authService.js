import { API_CONFIG } from '../config';

class AuthService {
  constructor() {
    this.token = null;
    this.user = null;
  }

  async login(credentials) {
    try {
      const response = await fetch(`${API_CONFIG.BASE_URL}${API_CONFIG.ENDPOINTS.AUTH}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(credentials)
      });

      if (!response.ok) {
        throw new Error('Authentication failed');
      }

      const data = await response.json();
      this.token = data.token;
      this.user = data.user;
      
      await chrome.storage.local.set({ 
        token: this.token,
        user: this.user 
      });

      return this.user;
    } catch (error) {
      throw new Error(`Login failed: ${error.message}`);
    }
  }

  async checkAuth() {
    try {
      const { token, user } = await chrome.storage.local.get(['token', 'user']);
      if (token && user) {
        this.token = token;
        this.user = user;
        return true;
      }
      return false;
    } catch (error) {
      return false;
    }
  }

  async logout() {
    this.token = null;
    this.user = null;
    await chrome.storage.local.remove(['token', 'user']);
  }

  getAuthHeaders() {
    return this.token ? {
      'Authorization': `Bearer ${this.token}`
    } : {};
  }
}

export const authService = new AuthService();