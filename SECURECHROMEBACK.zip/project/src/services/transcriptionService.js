import { API_CONFIG } from '../config';
import { authService } from './authService';

class TranscriptionService {
  async transcribe(audioBlob) {
    try {
      const formData = new FormData();
      formData.append('audio', audioBlob);

      const response = await fetch(`${API_CONFIG.BASE_URL}${API_CONFIG.ENDPOINTS.TRANSCRIBE}`, {
        method: 'POST',
        headers: {
          ...authService.getAuthHeaders()
        },
        body: formData
      });

      if (!response.ok) {
        throw new Error('Transcription failed');
      }

      const data = await response.json();
      return data.transcription;
    } catch (error) {
      throw new Error(`Transcription failed: ${error.message}`);
    }
  }

  async summarize(text) {
    try {
      const response = await fetch(`${API_CONFIG.BASE_URL}${API_CONFIG.ENDPOINTS.SUMMARIZE}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...authService.getAuthHeaders()
        },
        body: JSON.stringify({ text })
      });

      if (!response.ok) {
        throw new Error('Summarization failed');
      }

      const data = await response.json();
      return data.summary;
    } catch (error) {
      throw new Error(`Summarization failed: ${error.message}`);
    }
  }
}

export const transcriptionService = new TranscriptionService();