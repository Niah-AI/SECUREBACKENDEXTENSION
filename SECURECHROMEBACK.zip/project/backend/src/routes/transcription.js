import express from 'express';
import multer from 'multer';
import { authenticateToken } from '../middleware/auth.js';
import { groqClient } from '../config/groq.js';

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

router.post('/transcribe', authenticateToken, upload.single('audio'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No audio file provided' });
    }

    // Convert audio to base64
    const audioBase64 = req.file.buffer.toString('base64');

    const completion = await groqClient.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a highly accurate transcription assistant.'
        },
        {
          role: 'user',
          content: `Please transcribe this audio: ${audioBase64}`
        }
      ],
      model: 'mixtral-8x7b-32768'
    });

    res.json({ transcription: completion.choices[0].message.content });
  } catch (error) {
    res.status(500).json({ error: 'Transcription failed' });
  }
});

router.post('/summarize', authenticateToken, async (req, res) => {
  try {
    const { text } = req.body;

    if (!text) {
      return res.status(400).json({ error: 'No text provided' });
    }

    const completion = await groqClient.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a highly efficient summarization assistant.'
        },
        {
          role: 'user',
          content: `Please provide a concise summary of this text: ${text}`
        }
      ],
      model: 'mixtral-8x7b-32768'
    });

    res.json({ summary: completion.choices[0].message.content });
  } catch (error) {
    res.status(500).json({ error: 'Summarization failed' });
  }
});

export const transcriptionRoutes = router;